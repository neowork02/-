var APP = {

    // 페이지 초기화
    init : function() {
        this.initTopMenu();
        this.initSearch();
        this.initAllMenu();
        this.initScrolla();
        this.initPlaceHolder();
        this.initCheckboxAll();
        this.initRegex();
        this.initDatepicker();
        this.initCircleProgress();
        this.initAutoMatchHeight();
        this.initPoplayer();
        this.initDropdown();
        this.initBtnToTop();
        this.ie9Fix();
        this.initMobileLnb();
    },

    initMobileLnb: function() {
        $('.page-header').click(function(e){
            if( $(window).width() < 1024 )
            {
                e.preventDefault();

                $('.lnb-list').slideToggle('fast');
            }
        });
    },
    initDropdown : function() {
        $(document).on('click','[data-toggle="dropdown"]', function(e){
            e.preventDefault();

            $(this).parent().find('.dropdown-menu').toggle();
        });
    },

    initRegex : function() {
        $('[data-regex="number-only"]').on('keypress',  function(e){
            if (e.which != 8 && e.which != 0 &&  e.which != 45 && (e.which < 48 || e.which > 57)) {
                e.preventDefault();
            }
        });
    },

    initPoplayer : function() {
        $('[data-toggle="pop-layer"]').each(function(){
            var $this = $(this);
            if( $this.attr('poplayer-init') != 1 )
            {
                var width = typeof $this.data('width') !='undefined' &&  $this.data('width') ? $this.data('width') : 400;
                var height = typeof $this.data('height') !='undefined' &&  $this.data('height') ?  $this.data('height') : 400;
                var title =  typeof $this.data('title') !='undefined' &&  $this.data('title') ?  $this.data('title') : '새 팝업';

                $this.css({
                    'display':'none',
                    'position':'fixed',
                    'top' : '50%',
                    'left': '50%',
                    'width' : width,
                    'height' : height,
                    '-webkit-transform': 'translateX(-50%) translateY(-50%)',
                    '-moz-transform': 'translateX(-50%) translateY(-50%)',
                    '-ms-transform': 'translateX(-50%) translateY(-50%)',
                    '-o-transform': 'translateX(-50%) translateY(-50%)',
                    'transform': 'translateX(-50%) translateY(-50%)',
                    'z-index':-1
                });

                var content =  $this.html();
                $this.empty();

                var $header = $('<div>').addClass('pop-header');
                $header.append( $('<h4>').addClass('pop-title').html( title ) );
                $header.append( $('<button>').addClass('pop-close').attr('data-button','pop-close') );
                $this.append($header);

                var $body = $('<div>').addClass('pop-body').html( content );
                $this.append($body);

                $this.attr('poplayer-init', 1);

                var $clone = $this.clone();
                $this.remove();

                $('body').append($this);
            }
        });
    },

    // 상단메뉴 초기화
    initTopMenu : function() {
        var $header = $('#header');
        var $topMenu = $('.top-menu');

        $topMenu.mouseenter(function(){
            if(APP.isSearchOpen || APP.isAllMenuOpen) return;

            var mask = APP.UTILITY.mask({
                zIndex: 90
            });
            mask.attr('id','mask-for-top-menu');
            $('body').addClass('mask-opened').append(mask);

            $('#mask-for-top-menu').show();
            $topMenu.find('.submenu').show();
            $header.addClass('opened');
        }).mouseleave(function(){
            if(APP.isSearchOpen || APP.isAllMenuOpen) return;

            var $mask = $('#mask-for-top-menu');
            $mask.remove();
            $('body').removeClass('mask-opened');
            $(this).find('.submenu').hide();
            $header.removeClass('opened');
        });
    },

    // 검색바
    isSearchOpen : false,
    initSearch : function() {
        $('[data-button="search-toggle"]').click(function(e){
            e.preventDefault();

            if( APP.isSearchOpen ) {
                APP.Search.Close();
            }
            else {
                APP.Search.Open();
            }
        });
    },
    Search : {
        Open : function() {
            if(APP.isAllMenuOpen) {
                APP.AllMenu.Close();
            }

            $('#search').addClass('opened').find('.search-input').focus();
            $('[data-button="search-toggle"]').removeClass('btn-icon-search').addClass('btn-icon-close').text('검색창 닫기');

            var mask = APP.UTILITY.mask({
                zIndex: 90
            });
            mask.attr('id','mask-for-search');
            $('body').addClass('mask-opened').append(mask);

            $('#mask-for-search').show();

            APP.isSearchOpen = true;
        },
        Close : function() {
            var $mask = $('#mask-for-search');
            $mask.remove();
            $('body').removeClass('mask-opened');

            $('#search').removeClass('opened');
            $('[data-button="search-toggle"]').addClass('btn-icon-search').removeClass('btn-icon-close').text('검색창 열기');
            APP.isSearchOpen = false;
        }
    },

    // 전체 메뉴
    isAllMenuOpen : false,
    initAllMenu : function() {
        $('[data-button="menu-toggle"]').click(function(e){
            e.preventDefault();

            if( APP.isAllMenuOpen ) {
                APP.AllMenu.Close();
            }
            else {
                APP.AllMenu.Open();
            }
        });

        $('.all-menu > li> h4').click(function(e){
            e.preventDefault();
            $(this).parent().toggleClass('opened').siblings().removeClass('opened');
        });
    },
    AllMenu : {
        Open : function() {
            if(APP.isSearchOpen) {
                APP.Search.Close();
            }

            $('#nav').addClass('opened');
            $('[data-button="menu-toggle"]').removeClass('btn-icon-menu').addClass('btn-icon-close').text('전체 메뉴 닫기');

            var mask = APP.UTILITY.mask({
                zIndex: 90
            });
            mask.attr('id','mask-for-all-menu');
            $('body').addClass('mask-opened').append(mask);

            $('#mask-for-all-menu').show();

            APP.isAllMenuOpen = true;
        },
        Close: function() {
            var $mask = $('#mask-for-all-menu');
            $mask.remove();
            $('body').removeClass('mask-opened');

            $('#nav').removeClass('opened');
            $('[data-button="menu-toggle"]').addClass('btn-icon-menu').removeClass('btn-icon-close').text('전체 메뉴 열기');
            APP.isAllMenuOpen = false;
        }
    },

    initScrolla : function() {
        $('.animate').scrolla({
            mobile: true, // disable animation on mobiles
            once: false // only once animation play on scroll
        });
    },

    initPlaceHolder : function() {
        if( $('html').hasClass('ie9') )
        {
            $('input[placeholder], textarea[placeholder]').placeholder();
        }
    },


    initCheckboxAll : function(){
        $('[data-checkbox]').click(function(){
            var $check = $(this);
            var is_all = ($check.data('checkbox-all') && $check.data('checkbox-all').toString() == 'true');
            var name = $check.data('checkbox');
            var checked = $check.prop('checked');
            var $allCheck = is_all ? $check : $('[data-checkbox="'+name+'"][data-checkbox-all="true"]');

            if( is_all ) {
                $('[data-checkbox="'+name+'"]').prop('checked', checked );
            }
            else {
                $allCheck.prop('checked', $('[data-checkbox="'+name+'"]').not('[data-checkbox-all="true"]').length ==  $('[data-checkbox="'+name+'"]:checked').not('[data-checkbox-all="true"]').length);
            }
        });
    },

    ie9Fix : function() {
        if( $('html').hasClass('ie9') )
        {
            $('select.input').each(function(){
                var $wrap = $('<div>').addClass('select-input-wrap');
                var $parent = $(this).parent();
                $(this).appendTo($wrap);
                $parent.append( $wrap );
            });
        }
    },

    initDatepicker : function() {
        $.datepicker._updateDatepicker_original = $.datepicker._updateDatepicker;
        $.datepicker._updateDatepicker = function(inst) {
            $.datepicker._updateDatepicker_original(inst);
            var afterShow = this._get(inst, 'afterShow');
            if (afterShow)
                afterShow.apply((inst.input ? inst.input[0] : null));
        };
        $.datepicker.regional['ko'] = {
            closeText: '닫기',
            prevText: '이전달',
            nextText: '다음달',
            currentText: '오늘',
            monthNames: ['1월','2월','3월','4월','5월','6월', '7월','8월','9월','10월','11월','12월'],
            monthNamesShort: ['1월','2월','3월','4월','5월','6월', '7월','8월','9월','10월','11월','12월'],
            dayNames: ['일','월','화','수','목','금','토'],
            dayNamesShort: ['일','월','화','수','목','금','토'],
            dayNamesMin: ['일','월','화','수','목','금','토'],
            weekHeader: 'Wk',
            dateFormat: 'yymmdd',
            firstDay: 0,
            isRTL: false,
            showMonthAfterYear: true,
            yearSuffix: '',
            afterShow: function() {
                //$('.ui-datepicker-prev').empty().append( '<i class="far fa-chevron-left"></i>' );
                //$('.ui-datepicker-next').empty().append( '<i class="far fa-chevron-right"></i>' );
            }
        };

        $.datepicker.setDefaults($.datepicker.regional['ko']);
    },

    initCircleProgress : function() {
        $('[data-toggle="circle-progress"]').each(function(){
            var size = $(this).data('size') * 1;
            var value = $(this).data('value') * 0.01;
            var fill = $(this).data('color');
            var thickness  =$(this).data('thickness');
            var emptyFill = $(this).data('empty-fill');

            $(this).circleProgress({
                value : value,
                size: size,
                fill : {color:fill},
                emptyFill : emptyFill,
                thickness:thickness,
                lineCap:'round'
            });
        });
    },

    initAutoMatchHeight : function() {

        $(window).resize(function() {
            var matches = [];
            $('[data-match-height]').css({'min-height':'none','height':'auto'});
            $('[data-match-height]').each(function() {
                var seq = $(this).attr('data-match-height');
                if( typeof matches[seq] =='undefined' || matches[seq] == null ) matches[seq] = 0;
                if( $(this).outerHeight() > matches[seq] )
                    matches[seq] = $(this).outerHeight();
            });
            $('[data-match-height]').each(function(){
                var seq = $(this).attr('data-match-height');
                if( $(this).css('display') == 'table-cell' ) {
                    $(this).css({
                        'height' : matches[seq]
                    });
                }
                else {
                    $(this).css({
                        'min-height' : matches[seq]
                    });
                }

            });
        }).trigger('resize');
    },

    initBtnToTop : function(){
      $('[data-button="to-top"]').click(function(e){
         e.preventDefault();

         $('html,body').animate({
             scrollTop:0
         }, 300);
      });

        $(window).scroll(function(){
            var scrollTop = $(window).scrollTop();
            if(scrollTop > 100) {
                $('[data-button="to-top"]').fadeIn('fast');
            }
            else {
                $('[data-button="to-top"]').fadeOut('fast');
            }
        }).trigger('scroll');
    },

    getScrollbarWidth : function() {
        var outer = document.createElement("div");
        outer.style.visibility = "hidden";
        outer.style.width = "100px";
        outer.style.msOverflowStyle = "scrollbar";

        document.body.appendChild(outer);

        var widthNoScroll = outer.offsetWidth;
        // force scrollbars
        outer.style.overflow = "scroll";

        // add innerdiv
        var inner = document.createElement("div");
        inner.style.width = "100%";
        outer.appendChild(inner);

        var widthWithScroll = inner.offsetWidth;

        // remove divs
        outer.parentNode.removeChild(outer);

        return widthNoScroll - widthWithScroll;
    },
    // 유틸리티
    UTILITY : {
        mask : function(opts) {
            opts = typeof opts == 'object' && opts ? opts : new Object;
            opts.zIndex = typeof opts.zIndex == 'number' && opts.zIndex ? opts.zIndex : 1000;
            opts.opacity = typeof opts.opacity == 'number' && opts.opacity ? opts.opacity: 0.7;
            opts.bgColor = typeof opts.bgColor != 'undefined' && opts.bgColor ? opts.bgColor: '#000';

            return $('<div>').attr('data-mask', 'opened').css({
                'position': 'fixed',
                'top': 0,
                'left': 0,
                'width': '100%',
                'height': '100%',
                '-ms-filter': 'progid:DXImageTransform.Microsoft.Alpha(Opacity='+(opts.opacity*100)+')',
                'filter': 'progid:DXImageTransform.Microsoft.Alpha(Opacity='+(opts.opacity*100)+')',
                'opacity': opts.opacity,
                'background': opts.bgColor,
                '-moz-opacity': opts.opacity,
                'z-index': opts.zIndex,
                'display': 'none'
            });
        }
    }
};

$(function(){
    APP.init();
});