(function($){
    $.fn.wPopLayer = function(opts){
        return this.each(function() {
            var $popup = $(this);

            $popup.find('[data-button="pop-close"]').off('click.poplayer_close').on('click.poplayer_close', function(){
                // 배경 마스크 fadeOut 감춘뒤 삭제
                $popup.fadeOut('fast');

                $("[data-mask]").fadeOut('300',function(){
                    $("[data-mask]").remove();
                    $("body").css({
                        'overflow-y':'auto'
                    });
                });
            });
            var mask = $('<div>').attr('data-mask', 'opened').css({
                'position': 'fixed',
                'top': 0,
                'left': 0,
                'width': '100%',
                'height': '100%',
                '-ms-filter': 'progid:DXImageTransform.Microsoft.Alpha(Opacity=50)',
                'filter': 'progid:DXImageTransform.Microsoft.Alpha(Opacity=50)',
                'opacity': 0.5,
                'background': '#4a4a4a',
                '-moz-opacity': 0.5,
                'z-index': 1000,
                'display': 'none'
            });

            $('[data-toggle="pop-layer"]').hide();

            $('body').css('overflow-y','hidden').append(mask);
            $('[data-mask]').fadeTo('fast', 0.8);

            $popup.css({'z-index':1002}).fadeIn('fast');
        });
    }
})(jQuery);