/**********************************************************************************************************
 * 포함 CSS / JS
 ***********************************************************************************************************/
var srcs = {
    html : [
        'src/html/'
    ],
    css : [
        'src/scss/style.scss',
    ],
    js : [
        "node_modules/bxslider/dist/jquery.bxslider.js",
        "node_modules/jquery-circle-progress/dist/circle-progress.js",
        "node_modules/jquery-scrolla/src/scrolla.jquery.js",
        "node_modules/jquery-placeholder/jquery.placeholder.js",
        "src/js/jquery-ui-datepicker.js",
        "src/js/collapse.js",
        "src/js/jquery-confirm.js",
        "src/js/poplayer.js",
        "src/js/common.js",
        "src/js/ax5core.js",
        "src/js/ax5mask.js",
        "src/js/ax5modal.js",
        "src/js/modal.js",
        "src/js/tab.js"
    ]
};

/**********************************************************************************************************
 * 환경 설정
 ***********************************************************************************************************/
var destPath = 'dist/';
var sassOptions = {
    outputStyle : 'expanded'
};

/**********************************************************************************************************
 * 필요 라이브러리 로드
 ***********************************************************************************************************/
var gulp = require('gulp'),
    concat = require('gulp-concat'),    // 자바스크립트 파일을 하나로 합쳐주는 플러그인
    cleanCSS  = require('gulp-clean-css'),    // CSS파일을  압축해주는 플러그인
    sass = require('gulp-sass'),
    minify = require('gulp-minify'),    // 자바스크립트 파일 압축
    size = require('gulp-size'),
    cached = require('gulp-cached'),
    fileInclude = require('gulp-file-include'),
    watch = require('gulp-watch'),
    sourcemaps = require('gulp-sourcemaps'),
    spritesmith = require('gulp.spritesmith');

var src_html = [
    srcs.html + '*.html',
    srcs.html + '**/*.html',
    '!' + srcs.html + 'include/*.html', // include폴더 제외
    srcs.html + '**/**/*.html' // 레거시  iframe 폴더
];
var src_js = [
    "src/js/*.js",
    "src/js/**/*.js"
];
var src_scss =[
    "src/scss/*.scss",
    "src/scss/**/*.scss"
];

/**********************************************************************************************************
 * TASKS
 ***********************************************************************************************************/
gulp.task('html', function(){
    return gulp.src(src_html)
        .pipe(fileInclude({
            prefix : '@@',
            context : {
                ROOT : '.',
                checked : null,
                isAll : null,
                isLogin : true,
                classActive : '',
                active :''
            }
        }).on('error', function(err){ console.log(err.message); return false; }))
        .pipe(cached('include'))
        .pipe(size({ gzip:true, showFiles:true }))
        .pipe(size({ gzip: true, showFiles: true }))
        .pipe(gulp.dest(destPath));
});

gulp.task('scss:compile', function() {
    return gulp
        .src(srcs.css)
        .pipe(sourcemaps.init())
        .pipe(sass(sassOptions).on('error', sass.logError))
        .pipe(concat('style.css'))
        .pipe(gulp.dest(destPath + 'common/css/'))
        .pipe(cleanCSS())
        .pipe(concat('style.min.css'))
        .pipe(size({ gzip: true, showFiles: true }))
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest(destPath + 'common/css/'));
});

gulp.task('js:combine',function(){
    // 자바스크립트 압축실행
    return gulp.src(srcs.js)
        .pipe(concat('common.js'))
        .pipe(minify({
            ext :{
                src : '.js',
                min :'.min.js'
            }
        }))
        .pipe(size({ gzip: true, showFiles: true }))
        .pipe(gulp.dest(destPath + 'common/js/'));
});

gulp.task('sprite', function () {
    var packages = ['icon-package-default','icon-package-white','icon-package-primary','poll-icon','icon-classes-default','icon-classes-primary','icon-support-default','icon-support-active','icon-site-default','icon-site-active','icon-customer-default','icon-customer-active'];
    var spriteData = null;

    for(var i in packages) {
        spriteData = gulp.src('src/icons/'+packages[i]+'/*.png').pipe(spritesmith({
            imgName: packages[i] + '.png',
            cssName: packages[i] +'.css',
            imgPath : '../images/icons/',
            algorithm:'left-right'
        }));
        spriteData.img.pipe(gulp.dest(destPath + 'common/images/icons/'));
        spriteData.css.pipe(gulp.dest("src/icons/"));
    }

    return true;
});


gulp.task('watch', function(){
    gulp.watch(src_html, gulp.series(['html']));
    gulp.watch(src_js, gulp.series(['js:combine']));
    gulp.watch(src_scss, gulp.series(['scss:compile']));
});

gulp.task('default', gulp.series(['html', 'js:combine', 'scss:compile']));
